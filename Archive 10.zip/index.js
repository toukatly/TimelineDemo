(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,0,1537,873],[0,875,1070,1070]]},
		{name:"index_atlas_2", frames: [[0,0,1510,696],[0,698,1000,1000]]},
		{name:"index_atlas_3", frames: [[0,0,1315,756],[0,758,1315,756]]},
		{name:"index_atlas_4", frames: [[0,0,1315,756],[0,758,1315,756]]},
		{name:"index_atlas_5", frames: [[0,0,1315,756],[0,758,1315,756]]},
		{name:"index_atlas_6", frames: [[0,0,1315,756],[0,758,1315,756]]},
		{name:"index_atlas_7", frames: [[0,0,1315,756],[0,758,1315,756]]},
		{name:"index_atlas_8", frames: [[0,0,1315,756],[0,758,1315,756]]},
		{name:"index_atlas_9", frames: [[0,0,1315,756],[0,758,1315,756]]},
		{name:"index_atlas_10", frames: [[0,0,1315,756],[0,758,1315,756]]},
		{name:"index_atlas_11", frames: [[0,0,1315,756],[0,758,1315,756]]},
		{name:"index_atlas_12", frames: [[0,0,1315,756],[0,758,1315,756]]},
		{name:"index_atlas_13", frames: [[0,758,992,1000],[0,0,1315,756]]},
		{name:"index_atlas_14", frames: [[0,0,1307,756],[0,758,1307,756]]},
		{name:"index_atlas_15", frames: [[0,0,1307,756],[0,758,1307,756]]},
		{name:"index_atlas_16", frames: [[0,0,1307,756],[0,758,1307,756]]},
		{name:"index_atlas_17", frames: [[0,0,1307,756],[0,758,1307,756]]},
		{name:"index_atlas_18", frames: [[0,0,1307,756],[0,758,1307,756]]},
		{name:"index_atlas_19", frames: [[0,0,1307,756],[0,758,1307,756]]},
		{name:"index_atlas_20", frames: [[0,0,1307,756],[0,758,1307,756]]},
		{name:"index_atlas_21", frames: [[0,0,1307,756],[0,758,1307,756]]},
		{name:"index_atlas_22", frames: [[0,0,1307,756],[0,758,1307,756]]},
		{name:"index_atlas_23", frames: [[0,0,1307,756],[0,758,1307,756]]},
		{name:"index_atlas_24", frames: [[0,758,1235,756],[0,0,1307,756]]},
		{name:"index_atlas_25", frames: [[0,0,1235,756],[0,758,1235,756]]},
		{name:"index_atlas_26", frames: [[0,0,1235,756],[0,758,1235,756]]},
		{name:"index_atlas_27", frames: [[0,0,1235,756],[0,758,1235,756]]},
		{name:"index_atlas_28", frames: [[0,0,1235,756],[0,758,1235,756]]},
		{name:"index_atlas_29", frames: [[0,0,1235,756],[0,758,1235,756]]},
		{name:"index_atlas_30", frames: [[0,0,1235,756],[0,758,1235,756]]},
		{name:"index_atlas_31", frames: [[0,0,1235,756],[0,758,1235,756]]},
		{name:"index_atlas_32", frames: [[0,0,1235,756],[0,758,1235,756]]},
		{name:"index_atlas_33", frames: [[0,1468,1507,403],[0,0,1235,756],[0,758,1001,708],[1237,0,727,1000]]},
		{name:"index_atlas_34", frames: [[0,0,768,530],[861,0,3,371],[770,0,89,371]]}
];


(lib.AnMovieClip = function(){
	this.currentSoundStreamInMovieclip;
	this.actionFrames = [];
	this.soundStreamDuration = new Map();
	this.streamSoundSymbolsList = [];

	this.gotoAndPlayForStreamSoundSync = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.gotoAndPlay = function(positionOrLabel){
		this.clearAllSoundStreams();
		this.startStreamSoundsForTargetedFrame(positionOrLabel);
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		this.clearAllSoundStreams();
		this.startStreamSoundsForTargetedFrame(this.currentFrame);
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
		this.clearAllSoundStreams();
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
		this.clearAllSoundStreams();
	}
	this.startStreamSoundsForTargetedFrame = function(targetFrame){
		for(var index=0; index<this.streamSoundSymbolsList.length; index++){
			if(index <= targetFrame && this.streamSoundSymbolsList[index] != undefined){
				for(var i=0; i<this.streamSoundSymbolsList[index].length; i++){
					var sound = this.streamSoundSymbolsList[index][i];
					if(sound.endFrame > targetFrame){
						var targetPosition = Math.abs((((targetFrame - sound.startFrame)/lib.properties.fps) * 1000));
						var instance = playSound(sound.id);
						var remainingLoop = 0;
						if(sound.offset){
							targetPosition = targetPosition + sound.offset;
						}
						else if(sound.loop > 1){
							var loop = targetPosition /instance.duration;
							remainingLoop = Math.floor(sound.loop - loop);
							if(targetPosition == 0){ remainingLoop -= 1; }
							targetPosition = targetPosition % instance.duration;
						}
						instance.loop = remainingLoop;
						instance.position = Math.round(targetPosition);
						this.InsertIntoSoundStreamData(instance, sound.startFrame, sound.endFrame, sound.loop , sound.offset);
					}
				}
			}
		}
	}
	this.InsertIntoSoundStreamData = function(soundInstance, startIndex, endIndex, loopValue, offsetValue){ 
 		this.soundStreamDuration.set({instance:soundInstance}, {start: startIndex, end:endIndex, loop:loopValue, offset:offsetValue});
	}
	this.clearAllSoundStreams = function(){
		var keys = this.soundStreamDuration.keys();
		for(var i = 0;i<this.soundStreamDuration.size; i++){
			var key = keys.next().value;
			key.instance.stop();
		}
 		this.soundStreamDuration.clear();
		this.currentSoundStreamInMovieclip = undefined;
	}
	this.stopSoundStreams = function(currentFrame){
		if(this.soundStreamDuration.size > 0){
			var keys = this.soundStreamDuration.keys();
			for(var i = 0; i< this.soundStreamDuration.size ; i++){
				var key = keys.next().value; 
				var value = this.soundStreamDuration.get(key);
				if((value.end) == currentFrame){
					key.instance.stop();
					if(this.currentSoundStreamInMovieclip == key) { this.currentSoundStreamInMovieclip = undefined; }
					this.soundStreamDuration.delete(key);
				}
			}
		}
	}

	this.computeCurrentSoundStreamInstance = function(currentFrame){
		if(this.currentSoundStreamInMovieclip == undefined){
			if(this.soundStreamDuration.size > 0){
				var keys = this.soundStreamDuration.keys();
				var maxDuration = 0;
				for(var i=0;i<this.soundStreamDuration.size;i++){
					var key = keys.next().value;
					var value = this.soundStreamDuration.get(key);
					if(value.end > maxDuration){
						maxDuration = value.end;
						this.currentSoundStreamInMovieclip = key;
					}
				}
			}
		}
	}
	this.getDesiredFrame = function(currentFrame, calculatedDesiredFrame){
		for(var frameIndex in this.actionFrames){
			if((frameIndex > currentFrame) && (frameIndex < calculatedDesiredFrame)){
				return frameIndex;
			}
		}
		return calculatedDesiredFrame;
	}

	this.syncStreamSounds = function(){
		this.stopSoundStreams(this.currentFrame);
		this.computeCurrentSoundStreamInstance(this.currentFrame);
		if(this.currentSoundStreamInMovieclip != undefined){
			var soundInstance = this.currentSoundStreamInMovieclip.instance;
			if(soundInstance.position != 0){
				var soundValue = this.soundStreamDuration.get(this.currentSoundStreamInMovieclip);
				var soundPosition = (soundValue.offset?(soundInstance.position - soundValue.offset): soundInstance.position);
				var calculatedDesiredFrame = (soundValue.start)+((soundPosition/1000) * lib.properties.fps);
				if(soundValue.loop > 1){
					calculatedDesiredFrame +=(((((soundValue.loop - soundInstance.loop -1)*soundInstance.duration)) / 1000) * lib.properties.fps);
				}
				calculatedDesiredFrame = Math.floor(calculatedDesiredFrame);
				var deltaFrame = calculatedDesiredFrame - this.currentFrame;
				if(deltaFrame >= 2){
					this.gotoAndPlayForStreamSoundSync(this.getDesiredFrame(this.currentFrame,calculatedDesiredFrame));
				}
			}
		}
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_405 = function() {
	this.initialize(ss["index_atlas_24"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_409 = function() {
	this.initialize(ss["index_atlas_25"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_402 = function() {
	this.initialize(ss["index_atlas_25"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_410 = function() {
	this.initialize(ss["index_atlas_26"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_406 = function() {
	this.initialize(ss["index_atlas_26"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_404 = function() {
	this.initialize(ss["index_atlas_27"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_407 = function() {
	this.initialize(ss["index_atlas_27"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_403 = function() {
	this.initialize(ss["index_atlas_28"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_408 = function() {
	this.initialize(ss["index_atlas_28"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_400 = function() {
	this.initialize(ss["index_atlas_14"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_401 = function() {
	this.initialize(ss["index_atlas_14"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_398 = function() {
	this.initialize(ss["index_atlas_15"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_394 = function() {
	this.initialize(ss["index_atlas_15"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_395 = function() {
	this.initialize(ss["index_atlas_16"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_392 = function() {
	this.initialize(ss["index_atlas_16"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_399 = function() {
	this.initialize(ss["index_atlas_17"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_396 = function() {
	this.initialize(ss["index_atlas_17"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_397 = function() {
	this.initialize(ss["index_atlas_18"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_390 = function() {
	this.initialize(ss["index_atlas_18"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_391 = function() {
	this.initialize(ss["index_atlas_19"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_393 = function() {
	this.initialize(ss["index_atlas_19"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_389 = function() {
	this.initialize(ss["index_atlas_20"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_387 = function() {
	this.initialize(ss["index_atlas_20"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_382 = function() {
	this.initialize(ss["index_atlas_21"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_383 = function() {
	this.initialize(ss["index_atlas_21"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_388 = function() {
	this.initialize(ss["index_atlas_22"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_385 = function() {
	this.initialize(ss["index_atlas_22"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_384 = function() {
	this.initialize(ss["index_atlas_23"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_386 = function() {
	this.initialize(ss["index_atlas_23"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_381 = function() {
	this.initialize(ss["index_atlas_24"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_322 = function() {
	this.initialize(ss["index_atlas_33"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_321 = function() {
	this.initialize(ss["index_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_320 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_380 = function() {
	this.initialize(img.CachedBmp_380);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4211,605);


(lib.CachedBmp_379 = function() {
	this.initialize(img.CachedBmp_379);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4211,605);


(lib.CachedBmp_376 = function() {
	this.initialize(img.CachedBmp_376);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4211,605);


(lib.CachedBmp_317 = function() {
	this.initialize(ss["index_atlas_29"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_316 = function() {
	this.initialize(ss["index_atlas_29"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_315 = function() {
	this.initialize(ss["index_atlas_30"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_368 = function() {
	this.initialize(img.CachedBmp_368);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4211,605);


(lib.CachedBmp_375 = function() {
	this.initialize(img.CachedBmp_375);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4211,605);


(lib.CachedBmp_314 = function() {
	this.initialize(ss["index_atlas_30"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_364 = function() {
	this.initialize(img.CachedBmp_364);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4211,605);


(lib.CachedBmp_378 = function() {
	this.initialize(img.CachedBmp_378);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4211,605);


(lib.CachedBmp_313 = function() {
	this.initialize(ss["index_atlas_31"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_312 = function() {
	this.initialize(ss["index_atlas_31"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_318 = function() {
	this.initialize(img.CachedBmp_318);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2655,905);


(lib.CachedBmp_311 = function() {
	this.initialize(ss["index_atlas_32"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_309 = function() {
	this.initialize(ss["index_atlas_32"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_310 = function() {
	this.initialize(ss["index_atlas_33"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_308 = function() {
	this.initialize(ss["index_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_307 = function() {
	this.initialize(ss["index_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_306 = function() {
	this.initialize(ss["index_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_305 = function() {
	this.initialize(ss["index_atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_304 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_302 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_303 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_301 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_299 = function() {
	this.initialize(ss["index_atlas_7"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_300 = function() {
	this.initialize(ss["index_atlas_7"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_298 = function() {
	this.initialize(ss["index_atlas_8"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_297 = function() {
	this.initialize(ss["index_atlas_8"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_296 = function() {
	this.initialize(ss["index_atlas_9"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["index_atlas_34"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CALLOUTBG2x = function() {
	this.initialize(img.CALLOUTBG2x);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3546,1894);


(lib.senter9968aa = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.tootsierolls = function() {
	this.initialize(ss["index_atlas_33"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.line2x = function() {
	this.initialize(ss["index_atlas_34"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_295 = function() {
	this.initialize(ss["index_atlas_9"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.senter9629 = function() {
	this.initialize(ss["index_atlas_13"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(img.Bitmap21);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3840,2160);


(lib.divider = function() {
	this.initialize(img.divider);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,11,2081);


(lib.TSq16Vertical8x11 = function() {
	this.initialize(ss["index_atlas_33"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.linecrook2x = function() {
	this.initialize(ss["index_atlas_34"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.DCRibbonCutting1000thclub = function() {
	this.initialize(ss["index_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_294 = function() {
	this.initialize(ss["index_atlas_10"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_292 = function() {
	this.initialize(ss["index_atlas_10"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_293 = function() {
	this.initialize(ss["index_atlas_11"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_291 = function() {
	this.initialize(ss["index_atlas_11"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_290 = function() {
	this.initialize(ss["index_atlas_12"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_289 = function() {
	this.initialize(ss["index_atlas_12"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_288 = function() {
	this.initialize(ss["index_atlas_13"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_287 = function() {
	this.initialize(img.CachedBmp_287);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7875,1039);


(lib.CachedBmp_319 = function() {
	this.initialize(img.CachedBmp_319);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7867,4487);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib._99 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_410();
	this.instance.setTransform(22.7,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._99, new cjs.Rectangle(22.7,-56.5,617.5,378), null);


(lib._98 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_409();
	this.instance.setTransform(22.7,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._98, new cjs.Rectangle(22.7,-56.5,617.5,378), null);


(lib._97 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_408();
	this.instance.setTransform(23.7,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._97, new cjs.Rectangle(23.7,-56.5,617.5,378), null);


(lib._95 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.divider();
	this.instance.setTransform(710,-1717);

	this.instance_1 = new lib.CachedBmp_406();
	this.instance_1.setTransform(22.7,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._95, new cjs.Rectangle(22.7,-1717,698.3,2081), null);


(lib._94 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.divider();
	this.instance.setTransform(842,-1840);

	this.instance_1 = new lib.CachedBmp_405();
	this.instance_1.setTransform(156.7,-180.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._94, new cjs.Rectangle(156.7,-1840,696.3,2081), null);


(lib._93 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.divider();
	this.instance.setTransform(708,-1716);

	this.instance_1 = new lib.CachedBmp_404();
	this.instance_1.setTransform(22.7,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._93, new cjs.Rectangle(22.7,-1716,696.3,2081), null);


(lib._92 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.divider();
	this.instance.setTransform(909,-1659);

	this.instance_1 = new lib.CachedBmp_403();
	this.instance_1.setTransform(223.2,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._92, new cjs.Rectangle(223.2,-1659,696.8,2081), null);


(lib._91 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.divider();
	this.instance.setTransform(371,-1829);

	this.instance_1 = new lib.CachedBmp_402();
	this.instance_1.setTransform(-315.75,-168.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._91, new cjs.Rectangle(-315.7,-1829,697.7,2081), null);


(lib._20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_401();
	this.instance.setTransform(4.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._20, new cjs.Rectangle(4.9,-56.5,653.5,378), null);


(lib._19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_400();
	this.instance.setTransform(5.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._19, new cjs.Rectangle(5.9,-56.5,653.5,378), null);


(lib._18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_399();
	this.instance.setTransform(4.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._18, new cjs.Rectangle(4.9,-56.5,653.5,378), null);


(lib._17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_398();
	this.instance.setTransform(6.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._17, new cjs.Rectangle(6.9,-56.5,653.5,378), null);


(lib._16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_397();
	this.instance.setTransform(4.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._16, new cjs.Rectangle(4.9,-56.5,653.5,378), null);


(lib._15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_396();
	this.instance.setTransform(5.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._15, new cjs.Rectangle(5.9,-56.5,653.5,378), null);


(lib._14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_395();
	this.instance.setTransform(5.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._14, new cjs.Rectangle(5.9,-56.5,653.5,378), null);


(lib._13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_394();
	this.instance.setTransform(5.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._13, new cjs.Rectangle(5.9,-56.5,653.5,378), null);


(lib._12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_393();
	this.instance.setTransform(5.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._12, new cjs.Rectangle(5.9,-56.5,653.5,378), null);


(lib._11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_392();
	this.instance.setTransform(14.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._11, new cjs.Rectangle(14.9,-56.5,653.5,378), null);


(lib._10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_391();
	this.instance.setTransform(6.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._10, new cjs.Rectangle(6.9,-56.5,653.5,378), null);


(lib._09 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_390();
	this.instance.setTransform(4.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._09, new cjs.Rectangle(4.9,-56.5,653.5,378), null);


(lib._08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_389();
	this.instance.setTransform(4.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._08, new cjs.Rectangle(4.9,-56.5,653.5,378), null);


(lib._07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_388();
	this.instance.setTransform(4.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._07, new cjs.Rectangle(4.9,-56.5,653.5,378), null);


(lib._06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_387();
	this.instance.setTransform(4.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._06, new cjs.Rectangle(4.9,-56.5,653.5,378), null);


(lib._05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_386();
	this.instance.setTransform(4.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._05, new cjs.Rectangle(4.9,-56.5,653.5,378), null);


(lib._04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_385();
	this.instance.setTransform(-12.95,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._04, new cjs.Rectangle(-12.9,-56.5,653.5,378), null);


(lib._03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_384();
	this.instance.setTransform(-12.95,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._03, new cjs.Rectangle(-12.9,-56.5,653.5,378), null);


(lib._02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_383();
	this.instance.setTransform(4.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._02, new cjs.Rectangle(4.9,-56.5,653.5,378), null);


(lib._01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_382();
	this.instance.setTransform(4.85,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._01, new cjs.Rectangle(4.9,-56.5,653.5,378), null);


(lib._00 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_381();
	this.instance.setTransform(-12.95,-56.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._00, new cjs.Rectangle(-12.9,-56.5,653.5,378), null);


(lib.Symbol179 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_380();
	this.instance.setTransform(14560,-808.1,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_379();
	this.instance_1.setTransform(14559.95,-505.7,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_378();
	this.instance_2.setTransform(12454.4,-505.7,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_378();
	this.instance_3.setTransform(12454.45,-808.1,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_376();
	this.instance_4.setTransform(14559.9,-203.3,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_375();
	this.instance_5.setTransform(14559.9,99.1,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_375();
	this.instance_6.setTransform(12454.35,99.1,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_376();
	this.instance_7.setTransform(12454.4,-203.3,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_378();
	this.instance_8.setTransform(10348.85,-203.3,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_378();
	this.instance_9.setTransform(10348.8,99.1,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_378();
	this.instance_10.setTransform(8243.25,99.1,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_378();
	this.instance_11.setTransform(8243.25,-203.3,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_368();
	this.instance_12.setTransform(10348.85,-808.1,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_378();
	this.instance_13.setTransform(8243.25,-505.7,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_368();
	this.instance_14.setTransform(8243.25,-808.1,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_368();
	this.instance_15.setTransform(14559.9,401.5,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_364();
	this.instance_16.setTransform(14559.9,703.9,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_375();
	this.instance_17.setTransform(12454.4,703.9,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_378();
	this.instance_18.setTransform(12454.35,401.5,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_378();
	this.instance_19.setTransform(14560,1006.3,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_368();
	this.instance_20.setTransform(14560,1308.7,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_378();
	this.instance_21.setTransform(12454.45,1308.7,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_378();
	this.instance_22.setTransform(12454.4,1006.3,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_368();
	this.instance_23.setTransform(10348.85,1006.3,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_368();
	this.instance_24.setTransform(8243.25,1308.7,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_378();
	this.instance_25.setTransform(8243.25,1006.3,0.5,0.5);

	this.instance_26 = new lib.CachedBmp_378();
	this.instance_26.setTransform(10348.8,401.5,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_378();
	this.instance_27.setTransform(10348.85,703.9,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_378();
	this.instance_28.setTransform(8243.25,703.9,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_378();
	this.instance_29.setTransform(8243.25,401.5,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_368();
	this.instance_30.setTransform(6137.65,401.5,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_368();
	this.instance_31.setTransform(6137.65,703.9,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_368();
	this.instance_32.setTransform(4032.1,703.9,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_378();
	this.instance_33.setTransform(4032.1,401.5,0.5,0.5);

	this.instance_34 = new lib.CachedBmp_368();
	this.instance_34.setTransform(6137.65,1006.3,0.5,0.5);

	this.instance_35 = new lib.CachedBmp_368();
	this.instance_35.setTransform(6137.65,1308.7,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_378();
	this.instance_36.setTransform(4032.1,1308.7,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_368();
	this.instance_37.setTransform(4032.1,1006.3,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_368();
	this.instance_38.setTransform(1926.5,1006.3,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_368();
	this.instance_39.setTransform(-179.05,1308.7,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_378();
	this.instance_40.setTransform(-179.05,1006.3,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_368();
	this.instance_41.setTransform(1926.5,401.5,0.5,0.5);

	this.instance_42 = new lib.CachedBmp_378();
	this.instance_42.setTransform(-179.05,703.9,0.5,0.5);

	this.instance_43 = new lib.CachedBmp_368();
	this.instance_43.setTransform(-179.05,401.5,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_368();
	this.instance_44.setTransform(6137.65,-808.1,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_368();
	this.instance_45.setTransform(6137.65,-505.7,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_368();
	this.instance_46.setTransform(4032.1,-505.7,0.5,0.5);

	this.instance_47 = new lib.CachedBmp_378();
	this.instance_47.setTransform(4032.1,-808.1,0.5,0.5);

	this.instance_48 = new lib.CachedBmp_368();
	this.instance_48.setTransform(6137.65,-203.3,0.5,0.5);

	this.instance_49 = new lib.CachedBmp_368();
	this.instance_49.setTransform(6137.65,99.1,0.5,0.5);

	this.instance_50 = new lib.CachedBmp_378();
	this.instance_50.setTransform(4032.1,99.1,0.5,0.5);

	this.instance_51 = new lib.CachedBmp_368();
	this.instance_51.setTransform(4032.1,-203.3,0.5,0.5);

	this.instance_52 = new lib.CachedBmp_368();
	this.instance_52.setTransform(1926.5,-203.3,0.5,0.5);

	this.instance_53 = new lib.CachedBmp_368();
	this.instance_53.setTransform(-179.05,99.1,0.5,0.5);

	this.instance_54 = new lib.CachedBmp_378();
	this.instance_54.setTransform(-179.05,-203.3,0.5,0.5);

	this.instance_55 = new lib.CachedBmp_368();
	this.instance_55.setTransform(1926.5,-808.1,0.5,0.5);

	this.instance_56 = new lib.CachedBmp_378();
	this.instance_56.setTransform(-179.05,-505.7,0.5,0.5);

	this.instance_57 = new lib.CachedBmp_368();
	this.instance_57.setTransform(-179.05,-808.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-179,-808.1,16844.5,2419.3);


(lib._96_b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tootsierolls();
	this.instance.setTransform(81,-308,3,3.03);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._96_b, new cjs.Rectangle(81,-308,3003,2145.2), null);


(lib._96_a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.senter9968aa();
	this.instance.setTransform(-548,-533);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-548,-533,1070,1070);


(lib._15_d = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_322();
	this.instance.setTransform(-297.65,45.7,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_321();
	this.instance_1.setTransform(-297.95,-236.95,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_320();
	this.instance_2.setTransform(-299.95,-511.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-299.9,-511.5,768.5,758.7);


(lib.darken = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_319();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.darken, new cjs.Rectangle(0,0,3933.5,2243.5), null);


(lib._99on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_317();
	this.instance.setTransform(-308.25,-153.5,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._99on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._98on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_316();
	this.instance.setTransform(-308.25,-153.5,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._98on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._97on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_315();
	this.instance.setTransform(-308.25,-153.5,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._97on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._96on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_314();
	this.instance.setTransform(224.95,-152.95,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(150,-264);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._96on, new cjs.Rectangle(150,-264,768,530), null);


(lib._95on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_313();
	this.instance.setTransform(-308.25,-153.5,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._95on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._94on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_312();
	this.instance.setTransform(75.2,111,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._94on, new cjs.Rectangle(0,0,768,530), null);


(lib._93on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_311();
	this.instance.setTransform(-308.25,-153.5,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._93on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._92on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_310();
	this.instance.setTransform(75.2,111,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._92on, new cjs.Rectangle(0,0,768,530), null);


(lib._91on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_309();
	this.instance.setTransform(-308.75,-153.5,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._91on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._20_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.CachedBmp_308();
	this.instance_1.setTransform(-328.55,-153,0.5,0.5);

	this.instance_2 = new lib.Bitmap19();
	this.instance_2.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._20_1, new cjs.Rectangle(-384,-265,768,530), null);


(lib._19on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_307();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._19on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._18on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_306();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._18on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._17on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_305();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._17on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._16on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_304();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._16on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._15on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_303();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._15on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._14on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_302();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._14on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._13on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_301();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._13on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._12on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_300();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._12on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._11on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_299();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._11on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._10on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_298();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._10on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._09on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_297();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._09on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._08on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_296();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._08on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._07on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_295();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._07on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._06on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_294();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._06on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._05on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_293();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._05on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._04on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_292();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._04on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._03on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_291();
	this.instance.setTransform(-328.55,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._03on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._02on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_290();
	this.instance.setTransform(-328.05,-153,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._02on, new cjs.Rectangle(-384,-265,768,530), null);


(lib._01on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_289();
	this.instance.setTransform(-328.55,-13.5,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._01on, new cjs.Rectangle(-384,-125,768,530), null);


(lib._00on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_288();
	this.instance.setTransform(-328.55,-13.5,0.5,0.5);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-384,-125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._00on, new cjs.Rectangle(-384,-125,768,530), null);


(lib._96 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._96_b();
	this.instance.setTransform(1137.95,-206.3,0.1497,0.1497,0,0,0,1582.8,764.6);

	this.instance_1 = new lib.divider();
	this.instance_1.setTransform(1510,-1482);

	this.instance_2 = new lib.CachedBmp_407();
	this.instance_2.setTransform(820.6,179.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._96, new cjs.Rectangle(820.6,-1482,700.4,2081), null);


(lib.timeline = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// open
	this.open = new lib._20_1();
	this.open.name = "open";
	this.open.setTransform(22656,1183);
	this.open.visible = false;

	this.open_1 = new lib._19on();
	this.open_1.name = "open_1";
	this.open_1.setTransform(21888,1183);
	this.open_1.visible = false;

	this.open_2 = new lib._18on();
	this.open_2.name = "open_2";
	this.open_2.setTransform(21120,1183);
	this.open_2.visible = false;

	this.open_3 = new lib._17on();
	this.open_3.name = "open_3";
	this.open_3.setTransform(20352,1183);
	this.open_3.visible = false;

	this.open_4 = new lib._16on();
	this.open_4.name = "open_4";
	this.open_4.setTransform(19584,1183);
	this.open_4.visible = false;

	this.open_5 = new lib._15on();
	this.open_5.name = "open_5";
	this.open_5.setTransform(18816,1183);
	this.open_5.visible = false;

	this.open_6 = new lib._14on();
	this.open_6.name = "open_6";
	this.open_6.setTransform(18048,1183);
	this.open_6.visible = false;

	this.open_7 = new lib._13on();
	this.open_7.name = "open_7";
	this.open_7.setTransform(17280,1183);
	this.open_7.visible = false;

	this.open_8 = new lib._12on();
	this.open_8.name = "open_8";
	this.open_8.setTransform(16512,1183);
	this.open_8.visible = false;

	this.open_9 = new lib._11on();
	this.open_9.name = "open_9";
	this.open_9.setTransform(15744,1183);
	this.open_9.visible = false;

	this.open_10 = new lib._10on();
	this.open_10.name = "open_10";
	this.open_10.setTransform(14976,1183);
	this.open_10.visible = false;

	this.open_11 = new lib._09on();
	this.open_11.name = "open_11";
	this.open_11.setTransform(14208,1183);
	this.open_11.visible = false;

	this.open_12 = new lib._08on();
	this.open_12.name = "open_12";
	this.open_12.setTransform(13440,1183);
	this.open_12.visible = false;

	this.open_13 = new lib._07on();
	this.open_13.name = "open_13";
	this.open_13.setTransform(12672,1183);
	this.open_13.visible = false;

	this.open_14 = new lib._06on();
	this.open_14.name = "open_14";
	this.open_14.setTransform(11904,1183);
	this.open_14.visible = false;

	this.open_15 = new lib._05on();
	this.open_15.name = "open_15";
	this.open_15.setTransform(11136,1183);
	this.open_15.visible = false;

	this.open_16 = new lib._04on();
	this.open_16.name = "open_16";
	this.open_16.setTransform(10368,1183);
	this.open_16.visible = false;

	this.open_17 = new lib._03on();
	this.open_17.name = "open_17";
	this.open_17.setTransform(9600,1183);
	this.open_17.visible = false;

	this.open_18 = new lib._02on();
	this.open_18.name = "open_18";
	this.open_18.setTransform(8832,1183);
	this.open_18.visible = false;

	this.open_19 = new lib._01on();
	this.open_19.name = "open_19";
	this.open_19.setTransform(8064,1183,1,1,0,0,0,0,140);
	this.open_19.visible = false;

	this.open_20 = new lib._00on();
	this.open_20.name = "open_20";
	this.open_20.setTransform(7296,1183,1,1,0,0,0,0,140);
	this.open_20.visible = false;

	this.open_21 = new lib._99on();
	this.open_21.name = "open_21";
	this.open_21.setTransform(6528,1183);
	this.open_21.visible = false;

	this.open_22 = new lib._98on();
	this.open_22.name = "open_22";
	this.open_22.setTransform(5760,1183);
	this.open_22.visible = false;

	this.open_23 = new lib._97on();
	this.open_23.name = "open_23";
	this.open_23.setTransform(4992,1183);
	this.open_23.visible = false;

	this.open96 = new lib._96on();
	this.open96.name = "open96";
	this.open96.setTransform(4224,1183,1,1,0,0,0,534,1);
	this.open96.visible = false;

	this.open_24 = new lib._95on();
	this.open_24.name = "open_24";
	this.open_24.setTransform(3456,1183);
	this.open_24.visible = false;

	this.open_25 = new lib._94on();
	this.open_25.name = "open_25";
	this.open_25.setTransform(2688,1183,1,1,0,0,0,384,265);
	this.open_25.visible = false;

	this.open_26 = new lib._93on();
	this.open_26.name = "open_26";
	this.open_26.setTransform(1920,1183);
	this.open_26.visible = false;

	this.open91 = new lib._91on();
	this.open91.name = "open91";
	this.open91.setTransform(384,1183);
	this.open91.visible = false;

	this.open92 = new lib._92on();
	this.open92.name = "open92";
	this.open92.setTransform(1152,1183,1,1,0,0,0,384,265);
	this.open92.visible = false;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.open92},{t:this.open91},{t:this.open_26},{t:this.open_25},{t:this.open_24},{t:this.open96},{t:this.open_23},{t:this.open_22},{t:this.open_21},{t:this.open_20},{t:this.open_19},{t:this.open_18},{t:this.open_17},{t:this.open_16},{t:this.open_15},{t:this.open_14},{t:this.open_13},{t:this.open_12},{t:this.open_11},{t:this.open_10},{t:this.open_9},{t:this.open_8},{t:this.open_7},{t:this.open_6},{t:this.open_5},{t:this.open_4},{t:this.open_3},{t:this.open_2},{t:this.open_1},{t:this.open}]}).wait(1));

	// clickable
	this.instance = new lib._20();
	this.instance.setTransform(22656.5,1219.25,1,1,0,0,0,331.5,132.5);

	this.instance_1 = new lib._19();
	this.instance_1.setTransform(21888.3,1219.25,1,1,0,0,0,332.5,132.5);

	this.instance_2 = new lib._18();
	this.instance_2.setTransform(21120.15,1219.25,1,1,0,0,0,331.5,132.5);

	this.instance_3 = new lib._17();
	this.instance_3.setTransform(20351.95,1219.25,1,1,0,0,0,333.5,132.5);

	this.instance_4 = new lib._16();
	this.instance_4.setTransform(19584.75,1219.25,1,1,0,0,0,331.5,132.5);

	this.instance_5 = new lib._15();
	this.instance_5.setTransform(18816.55,1219.3,1,1,0,0,0,332.5,132.5);

	this.instance_6 = new lib._14();
	this.instance_6.setTransform(18047.4,1219.3,1,1,0,0,0,332.5,132.5);

	this.instance_7 = new lib._13();
	this.instance_7.setTransform(17279.25,1219.3,1,1,0,0,0,332.5,132.5);

	this.instance_8 = new lib._12();
	this.instance_8.setTransform(16512,1219.25,1,1,0,0,0,332.5,132.5);

	this.instance_9 = new lib._11();
	this.instance_9.setTransform(15743.8,1219.25,1,1,0,0,0,341.5,132.5);

	this.instance_10 = new lib._10();
	this.instance_10.setTransform(14975.65,1219.25,1,1,0,0,0,333.5,132.5);

	this.instance_11 = new lib._09();
	this.instance_11.setTransform(14208.45,1219.25,1,1,0,0,0,331.5,132.5);

	this.instance_12 = new lib._08();
	this.instance_12.setTransform(13440.25,1219.25,1,1,0,0,0,331.5,132.5);

	this.instance_13 = new lib._07();
	this.instance_13.setTransform(12672.05,1219.25,1,1,0,0,0,331.5,132.5);

	this.instance_14 = new lib._06();
	this.instance_14.setTransform(11903.85,1219.25,1,1,0,0,0,331.5,132.5);

	this.instance_15 = new lib._05();
	this.instance_15.setTransform(11135.7,1219.25,1,1,0,0,0,331.5,132.5);

	this.instance_16 = new lib._04();
	this.instance_16.setTransform(10368.5,1219.25,1,1,0,0,0,313.7,132.5);

	this.instance_17 = new lib._03();
	this.instance_17.setTransform(9599.35,1219.25,1,1,0,0,0,313.7,132.5);

	this.instance_18 = new lib._02();
	this.instance_18.setTransform(8833.1,1219.3,1,1,0,0,0,331.5,132.5);

	this.instance_19 = new lib._01();
	this.instance_19.setTransform(8063.95,1218.3,1,1,0,0,0,331.5,132.5);

	this.instance_20 = new lib._00();
	this.instance_20.setTransform(7296.8,1218.25,1,1,0,0,0,313.7,132.5);

	this.instance_21 = new lib._99();
	this.instance_21.setTransform(6528.5,1218.25,1,1,0,0,0,331.5,132.5);

	this.instance_22 = new lib._98();
	this.instance_22.setTransform(5760.35,1218.25,1,1,0,0,0,331.5,132.5);

	this.instance_23 = new lib._97();
	this.instance_23.setTransform(4992.2,1218.25,1,1,0,0,0,332.5,132.5);

	this.instance_24 = new lib._93();
	this.instance_24.setTransform(1920.4,1218.3,1,1,0,0,0,331.5,132.5);

	this.TL91 = new lib._91();
	this.TL91.name = "TL91";
	this.TL91.setTransform(383.6,1218.8,1,1,0,0,0,-7,21);

	this.TL92 = new lib._92();
	this.TL92.name = "TL92";
	this.TL92.setTransform(1167.75,1182.85,1,1,0,0,0,548,154);

	this.instance_25 = new lib._15_d("synched",0);
	this.instance_25.setTransform(13405.55,2026.8,0.5,0.5,0,0,0,84.4,-132.1);

	this.instance_26 = new lib.TSq16Vertical8x11();
	this.instance_26.setTransform(13772,1845,0.5,0.5);

	this.instance_27 = new lib.senter9629();
	this.instance_27.setTransform(13668,542,0.45,0.45);

	this.instance_28 = new lib.DCRibbonCutting1000thclub();
	this.instance_28.setTransform(13039,289,0.46,0.46);

	this.instance_29 = new lib.linecrook2x();
	this.instance_29.setTransform(13305,742,1.2,1.2);

	this.instance_30 = new lib.line2x();
	this.instance_30.setTransform(13856,780,1.1,1.1);

	this.instance_31 = new lib.line2x();
	this.instance_31.setTransform(13408,1449,1.1,1.1);

	this.instance_32 = new lib.linecrook2x();
	this.instance_32.setTransform(13856,1448,1.1499,1.1499);

	this.movieClip_1 = new lib._94();
	this.movieClip_1.name = "movieClip_1";
	this.movieClip_1.setTransform(2222.3,1209.55);

	this.instance_33 = new lib._95();
	this.instance_33.setTransform(3455.9,1218,1,1,0,0,0,330.6,131.7);

	this.TL96 = new lib._96();
	this.TL96.name = "TL96";
	this.TL96.setTransform(3286.4,1209.5,1,1,0,0,0,192,360);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.TL96},{t:this.instance_33},{t:this.movieClip_1},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.TL92},{t:this.TL91},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// invisible
	this.instance_34 = new lib.Symbol179("synched",0);
	this.instance_34.setTransform(16486.5,803.1,1,1,0,0,0,16486.5,803.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_34).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.timeline, new cjs.Rectangle(-179,-808.1,23219,3153.1), null);


(lib._1996callout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_318();
	this.instance.setTransform(1372.85,598.05,0.5,0.5);

	this.instance_1 = new lib._96_a("synched",0);
	this.instance_1.setTransform(1563.45,1298,0.75,0.75,0,0,0,992.3,622.6);

	this.instance_2 = new lib.CALLOUTBG2x();
	this.instance_2.setTransform(-198,-165);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._1996callout, new cjs.Rectangle(-198,-165,3546,1894), null);


// stage content:
(lib.TimelineDraggable_NEW_copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.clearAllSoundStreams();
		 
		var that = this;
		var pages;
		
		that.start = function ()
		
		{
		 var stage = new createjs.Stage("canvas");
		 createjs.Touch.enable(stage);	
			stage.mouseMoveOutside = true;
			
			pages = that.timeline1;
			pages.on("mousedown",that.mouseDownHandler);
			
		}
		
		that.mouseDownHandler = function(e)
		{
			e.currentTarget.offsetX = (e.stageX / stage.scaleX) - e.currentTarget.x;
			pages.on("pressmove",that.pressMoveHandler);	
			};
			
		that.pressMoveHandler = function(e)
			{
				e.currentTarget.x = (e.stageX / stage.scaleX) - e.currentTarget.offsetX;
			};
		setTimeout(that.start,0);
			
		//click the year to open thumbnails//
		that.timeline1.TL92.on('click', function(){
		that.timeline1.open92.visible = true;
		that.darken1.visible = true;
		});	
			
		that.timeline1.TL96.on('click', function(){
		that.movieClip_1.visible = true;
		that.timeline1.open96.visible = true;
		that.darken1.visible = true;
		});
		
		//click the thumbnail to open callout//
		
		
		//click the callout to close all//
		that.movieClip_1.on('click', function(){
		that.movieClip_1.visible = false;
			that.darken1.visible = false;
			that.timeline1.open96.visible = false;
		});
		
		//click the active tab to close all//
		that.timeline1.open96.on('click', function(){
		that.movieClip_1.visible = false;
			that.darken1.visible = false;
			that.timeline1.open96.visible = false;
		});
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// movieClip_1
	this.movieClip_1 = new lib._1996callout();
	this.movieClip_1.name = "movieClip_1";
	this.movieClip_1.setTransform(1764.2,1022.9,1,1,0,0,0,1350,833.2);
	this.movieClip_1.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.movieClip_1).wait(1));

	// tl
	this.timeline1 = new lib.timeline();
	this.timeline1.name = "timeline1";
	this.timeline1.setTransform(1920,1072.35,1,1,0,0,0,1920,360);

	this.timeline.addTween(cjs.Tween.get(this.timeline1).wait(1));

	// tlbg
	this.instance = new lib.CachedBmp_287();
	this.instance.setTransform(-43.95,1700,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// darken
	this.darken1 = new lib.darken();
	this.darken1.name = "darken1";
	this.darken1.setTransform(1966.9,1121.7,1,1,0,0,0,1966.9,1121.7);
	this.darken1.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.darken1).wait(1));

	// dots
	this.instance_1 = new lib.Bitmap21();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(1741,984.3,21299,2073.1000000000004);
// library properties:
lib.properties = {
	id: '1EC90F576869490791343EAEFCAA263E',
	width: 3840,
	height: 2160,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CachedBmp_380.png", id:"CachedBmp_380"},
		{src:"images/CachedBmp_379.png", id:"CachedBmp_379"},
		{src:"images/CachedBmp_376.png", id:"CachedBmp_376"},
		{src:"images/CachedBmp_368.png", id:"CachedBmp_368"},
		{src:"images/CachedBmp_375.png", id:"CachedBmp_375"},
		{src:"images/CachedBmp_364.png", id:"CachedBmp_364"},
		{src:"images/CachedBmp_378.png", id:"CachedBmp_378"},
		{src:"images/CachedBmp_318.png", id:"CachedBmp_318"},
		{src:"images/CALLOUTBG2x.png", id:"CALLOUTBG2x"},
		{src:"images/Bitmap21.png", id:"Bitmap21"},
		{src:"images/divider.png", id:"divider"},
		{src:"images/CachedBmp_287.png", id:"CachedBmp_287"},
		{src:"images/CachedBmp_319.png", id:"CachedBmp_319"},
		{src:"images/index_atlas_1.png", id:"index_atlas_1"},
		{src:"images/index_atlas_2.png", id:"index_atlas_2"},
		{src:"images/index_atlas_3.png", id:"index_atlas_3"},
		{src:"images/index_atlas_4.png", id:"index_atlas_4"},
		{src:"images/index_atlas_5.png", id:"index_atlas_5"},
		{src:"images/index_atlas_6.png", id:"index_atlas_6"},
		{src:"images/index_atlas_7.png", id:"index_atlas_7"},
		{src:"images/index_atlas_8.png", id:"index_atlas_8"},
		{src:"images/index_atlas_9.png", id:"index_atlas_9"},
		{src:"images/index_atlas_10.png", id:"index_atlas_10"},
		{src:"images/index_atlas_11.png", id:"index_atlas_11"},
		{src:"images/index_atlas_12.png", id:"index_atlas_12"},
		{src:"images/index_atlas_13.png", id:"index_atlas_13"},
		{src:"images/index_atlas_14.png", id:"index_atlas_14"},
		{src:"images/index_atlas_15.png", id:"index_atlas_15"},
		{src:"images/index_atlas_16.png", id:"index_atlas_16"},
		{src:"images/index_atlas_17.png", id:"index_atlas_17"},
		{src:"images/index_atlas_18.png", id:"index_atlas_18"},
		{src:"images/index_atlas_19.png", id:"index_atlas_19"},
		{src:"images/index_atlas_20.png", id:"index_atlas_20"},
		{src:"images/index_atlas_21.png", id:"index_atlas_21"},
		{src:"images/index_atlas_22.png", id:"index_atlas_22"},
		{src:"images/index_atlas_23.png", id:"index_atlas_23"},
		{src:"images/index_atlas_24.png", id:"index_atlas_24"},
		{src:"images/index_atlas_25.png", id:"index_atlas_25"},
		{src:"images/index_atlas_26.png", id:"index_atlas_26"},
		{src:"images/index_atlas_27.png", id:"index_atlas_27"},
		{src:"images/index_atlas_28.png", id:"index_atlas_28"},
		{src:"images/index_atlas_29.png", id:"index_atlas_29"},
		{src:"images/index_atlas_30.png", id:"index_atlas_30"},
		{src:"images/index_atlas_31.png", id:"index_atlas_31"},
		{src:"images/index_atlas_32.png", id:"index_atlas_32"},
		{src:"images/index_atlas_33.png", id:"index_atlas_33"},
		{src:"images/index_atlas_34.png", id:"index_atlas_34"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['1EC90F576869490791343EAEFCAA263E'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;